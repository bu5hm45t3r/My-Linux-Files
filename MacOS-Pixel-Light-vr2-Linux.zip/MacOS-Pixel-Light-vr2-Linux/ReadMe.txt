Created by MOYASH.
----------------------------------------------------------------------

to install: 

just move "MacOS-Pixel-Light-vr2" folder to your ".icons" folder.


----------------------------------------------------------------------
License:(CC BY-NC-ND) 
---------------------------

Thanks for Downloading my Work.